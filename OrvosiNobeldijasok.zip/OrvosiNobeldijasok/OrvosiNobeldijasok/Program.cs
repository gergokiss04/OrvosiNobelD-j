﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;
using System.Runtime.Remoting.Messaging;
using System.Collections;

namespace OrvosiNobeldijasok
{
    internal class Program
    {
        static void Main(string[] args)
        {
            StreamReader sr = new StreamReader("orvosi_nobeldijak.txt");
            List<dij> listam = new List<dij>();

            sr.ReadLine();
            while (!sr.EndOfStream)
            {
                string sor = sr.ReadLine();
                string[] darabok = sor.Split(';');
                dij a = new dij();
                a.year =int.Parse(darabok[0]);
                a.name = darabok[1];
                a.borndied = darabok[2];
                a.countrycode = darabok[3];
                listam.Add(a);

                
            }
            sr.Close();



            //3.Feladat:

            Console.WriteLine($"3.Feladat:Díjazottak száma:{listam.Count}"+" fő.");

            //4.Feladat:

            int lastyear = listam.OrderBy(x => x.year).Last().year;
            Console.WriteLine("4.Feladat:Utolso év:"+lastyear);

            //5.Feladat:

            Console.Write("Kérem adjon meg egy országkódot!");
            string code = Console.ReadLine();
            int piece = 0;

            foreach (var item in listam)
            {
                if (item.countrycode==code)
                {
                    piece++;    
                }

            }

            foreach (var item in listam)
            {
                if (item.countrycode == code && piece == 1)
                {
                    Console.WriteLine($"Név: {item.name}");
                    Console.WriteLine($"Év: {item.year}");
                    Console.WriteLine($"SZ/H: {item.borndied}");
                    
                }
                else if (piece == 0)
                {
                    Console.WriteLine("A megadott országból nem volt díjazott!");
                    break;
                }
            }

            foreach (var item in listam)
            {
                if (piece!=1 && piece>0)
                {
                    Console.WriteLine($"A megadott országból {piece} fő díjazott volt!");
                    break;
                }

                
            }


            //6.Feladat:
            Console.WriteLine("6.Feladat:Statisztika");
            Dictionary<string, int> osszes = new Dictionary<string, int>();
            foreach (var item in listam)
            {
                if (!osszes.ContainsKey(item.countrycode))
                {

                    osszes.Add(item.countrycode, 1);

                }
                else
                {

                    osszes[item.countrycode]++;
                }
            }


            foreach (var item in osszes)
            {
                if (item.Value>=5)
                {
                 Console.WriteLine(item.Key + " " + item.Value+" fő");
                }

               
            }

            //7.Feladat:

            double ossze = 0;
            double ismert = 0;
            for (int i = 0; i < listam.Count; i++)
            {
                Elethossz e = new Elethossz(listam[i].borndied);
                if (e.IsmertAzElethossz)
                {
                    ossze += e.ElethosszEvekben;
                    ismert++;
                }
            }
            double atlag = ossze / ismert;
            Console.WriteLine("7. feladat: a keresett átlag: " + Math.Round(atlag, 1) + " év");



            Console.ReadKey();
        }
    }
}
