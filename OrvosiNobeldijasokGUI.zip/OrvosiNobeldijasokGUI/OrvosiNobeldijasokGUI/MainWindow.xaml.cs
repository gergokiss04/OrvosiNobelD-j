﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace OrvosiNobeldijasokGUI
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void btn1_Click(object sender, RoutedEventArgs e)
        {
            var num = tb1.Text;
            

            if (tb1.Text=="" || tb2.Text=="" || tb3.Text == "" || tb4.Text == "")
            {
                MessageBox.Show("Töltsön ki minden mezőt!");
            }
            else if (int.Parse(num)<=1989)
            {
                MessageBox.Show("Hiba! Az évszám nem megfelelő!");
            }
            else
            {
                try
                {
                    StreamWriter sw = new StreamWriter("uj_dijazott.txt", true, Encoding.UTF8);
                    File.Exists("uj_dijazott.txt");
                   // sw.WriteLine("Év;Név;SzületésHalálozás;Országkód");
                    sw.WriteLine(tb1.Text + ";" + tb2.Text + ";" + tb3.Text + ";" + tb4.Text);
                    sw.Close();

                }
                catch (Exception a)
                {
                    MessageBox.Show("Hiba az állomány írásánál! \n" + a.Message);

                }

                try
                {
                    StreamWriter sw = new StreamWriter("uj_dijazott.txt", false, Encoding.UTF8);
                    File.Exists("uj_dijazott.txt");
                    sw.WriteLine("Év;Név;SzületésHalálozás;Országkód");
                    sw.WriteLine(tb1.Text + ";" + tb2.Text + ";" + tb3.Text + ";" + tb4.Text);
                    sw.Close();

                }
                catch (Exception a)
                {
                    MessageBox.Show("Hiba az állomány írásánál! \n" + a.Message);

                }

                MessageBox.Show("Sikeres mentés!");
                tb1.Clear();
                tb2.Clear();
                tb3.Clear();
                tb4.Clear();
            }


            
            
        }
    }
}
